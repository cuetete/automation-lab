README FIRST

To install this version of Code Composer Studio(tm), follow these steps:

(1) Double-click on setup_CCS_4.2.4.xxxxx.zip
(2) On the menu bar, go to Actions -> Extract
(3) Select the directory where you wish to extract the files
(4) Select all of the following:
    a. "All files/folders in archive"
    b. Overwrite existing files
    c. Use folder name
(5) De-select the following:
    a. Open Explorer Window
    b. Skip older files
(6) Click on Extract
(7) Once extraction has successfully completed, click on setup_CCS_4.2.4.xxxxx.exe
    and follow the installation instructions

Release notes available at: http://tiexpressdsp.com/index.php/Release_Notes_CCSv4

(c) Texas Instruments 2011